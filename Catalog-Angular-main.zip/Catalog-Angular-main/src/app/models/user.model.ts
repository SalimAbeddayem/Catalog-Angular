export interface AppUser {
  userId : string,
  username : string;
  password : string;
  roles : string[];
}
